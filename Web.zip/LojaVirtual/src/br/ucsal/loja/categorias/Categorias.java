package br.ucsal.loja.categorias;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Categorias")
public class Categorias extends HttpServlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6793105300356800648L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		//Par�metros camisas
		String cam1 = req.getParameter("cam1");
		String cam2 = req.getParameter("cam2");
		String cam3 = req.getParameter("cam3");
		//Par�metros cal�as
		String cal1 = req.getParameter("cal1");
		String cal2 = req.getParameter("cal2");
		String cal3 = req.getParameter("cal3");
		//Par�metros t�nis
		String ten1 = req.getParameter("ten1");
		String ten2 = req.getParameter("ten2");
		String ten3 = req.getParameter("ten3");
		
		PrintWriter out = new PrintWriter(resp.getOutputStream());
		//Camisas
		out.println(cam1);
		out.println(cam2);
		out.println(cam3);
		//Cal�as
		out.println(cal1);
		out.println(cal2);
		out.println(cal3);
		//T�nis
		out.println(ten1);
		out.println(ten2);
		out.println(ten3);
		
		out.close();
	}
}
 	